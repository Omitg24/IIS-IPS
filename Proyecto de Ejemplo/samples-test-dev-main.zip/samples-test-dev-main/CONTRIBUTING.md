# Contributing to samples-test-dev

This Project is a reduced version of [samples-test-java](https://github.com/javiertuya/samples-test-java)
to make easier its use as a base template project in SE development lab practices.

Any edit affecting the source code must be done in the `samples-test-java` project and then
this reduced version generated as indicated in 
[samples-test-java/CONTRIBUTING.md](https://github.com/javiertuya/samples-test-java/blob/main/CONTRIBUTING.md)
  